JH Web Duo

JH Web Duo is an open-source typeface released under the SIL Open Font License (OFL).

This font may be used freely for both commercial and non-commercial projects.
You are allowed to modify the font and redistribute original or modified versions,
as long as the license terms are preserved.

Files included in this package:
- README.txt : This file
- OFL.txt    : Full license text (legally binding)

Font formats:
- OTF : Desktop use
- WOFF : Web use

License summary:
You are free to:
- Use the font commercially and non-commercially
- Modify the font
- Redistribute the font and modified versions

You may not:
- Sell the font by itself
- Change the license

For the complete license terms, see OFL.txt.

Version: 1.0.0
Designer: Jaehyeon Lee

------------------------------------------------------------

제이에이치 웹 듀오

제이에이치 웹 듀오는 SIL 오픈 폰트 라이선스(OFL)로 배포되는 오픈소스 글꼴입니다.

이 글꼴은 상업적·비상업적 프로젝트 모두에서 자유롭게 사용할 수 있으며,
수정 및 재배포 또한 허용됩니다.
단, 라이선스 조건은 반드시 유지되어야 합니다.

이 패키지에 포함된 파일:
- README.txt : 본 파일
- OFL.txt    : 법적 효력을 가지는 라이선스 전문

글꼴 포맷:
- OTF : 데스크톱 사용
- WOFF : 웹 사용

라이선스 요약:

허용 사항:
- 상업적·비상업적 사용
- 글꼴 수정
- 원본 및 수정본 재배포

제한 사항:
- 글꼴 단독 판매 금지
- 라이선스 변경 금지

자세한 라이선스 내용은 OFL.txt 파일을 참고하세요.

버전: 1.0.0
디자이너: 이재현 (Jaehyeon Lee)
