(function(){

    var proceed = confirm("마크다운을 책으로\r이 스크립트를 실행하면 페이지가 일부 혹은 전체가 삭제될 수 있습니다.");
    if(!proceed) return;

    if(app.documents.length === 0){
        alert("문서가 열려있지 않습니다.");
        return;
    }

    var doc = app.activeDocument;
    
    var masterToUse = null;
    try{
        masterToUse = doc.masterSpreads.itemByName("A-Master");
        if(!masterToUse.isValid){
            masterToUse = doc.masterSpreads[0];
        }
    } catch(e){
        try{
            masterToUse = doc.masterSpreads[0];
        } catch(e2){
            masterToUse = null;
        }
    }

    var file = File.openDialog("텍스트 파일 선택", "*.md;*.txt");
    if(!file) return;

    if(!file.name.match(/\.(md|txt)$/i)){
        alert("텍스트 파일(.md .txt)만 열 수 있습니다.");
        return;
    }

    file.open("r");
    var markdownText = file.read();
    file.close();

    var cancelled = false;

    var progressWin = new Window("palette", "마크다운을 책으로");
    progressWin.orientation = "column";
    progressWin.alignChildren = ["fill", "top"];

    var progressText = progressWin.add("statictext", undefined, "진행 중...");
    var progressBar = progressWin.add("progressbar", undefined, 0, 100);
    var cancelBtn = progressWin.add("button", undefined, "Cancel");

    progressBar.preferredSize.width = 320;

    progressWin.show();
    progressBar.value = 1;
    progressWin.update();

    cancelBtn.onClick = function(){
        cancelled = true;
    };

    function updateProgress(value){

        if(cancelled) throw "사용자 취소";
    
        if(value < 0) value = 0;
        if(value > 100) value = 100;
    
        progressBar.value = value;
    
        progressWin.update();
    }

    markdownText = markdownText.replace(/\r\n|\n|\r/g, "\r");

    
    markdownText = markdownText.replace(/\\\\/g, "%%ESCAPED_BACKSLASH%%");

    markdownText = markdownText.replace(/\\\d+\./g, function(m){
        return "%%ESCAPED_ORDERED%%" + m.substring(1);
    });

    markdownText = markdownText.replace(/\\\*\*/g, "%%ESCAPED_DOUBLEASTERISK%%");
    markdownText = markdownText.replace(/\\\*/g, "%%ESCAPED_ASTERISK%%");

    markdownText = markdownText.replace(/\\~/g, "%%ESCAPED_SINGLE_TILDE%%");

    markdownText = markdownText.replace(/\\#/g, "%%ESCAPED_HASH%%");
    markdownText = markdownText.replace(/\\>/g, "%%ESCAPED_GT%%");
    markdownText = markdownText.replace(/\\-/g, "%%ESCAPED_DASH%%");
    markdownText = markdownText.replace(/\\\+{3}/g, "%%ESCAPED_PLUS%%");

    app.doScript(function(){

        updateProgress(10);

        app.findTextPreferences = NothingEnum.NOTHING;
        app.changeTextPreferences = NothingEnum.NOTHING;
        app.findGrepPreferences = NothingEnum.NOTHING;
        app.changeGrepPreferences = NothingEnum.NOTHING;

        function ensureParagraphStyle(name){
            var s = doc.paragraphStyles.itemByName(name);
            if(!s.isValid){
                s = doc.paragraphStyles.add({ name: name });
            }
            return s;
        }

        function ensureCharacterStyle(name){
            var s = doc.characterStyles.itemByName(name);
            if(!s.isValid){
                s = doc.characterStyles.add({ name: name });
            }
            return s;
        }

        var bodyStyle = ensureParagraphStyle("본문");

        ensureParagraphStyle("제목 1");
        ensureParagraphStyle("제목 2");
        ensureParagraphStyle("제목 3");
        ensureParagraphStyle("제목 4");
        ensureParagraphStyle("제목 5");
        ensureParagraphStyle("제목 6");

        ensureParagraphStyle("인용문");
        ensureParagraphStyle("순서가 중요하지 않은 목록");
        ensureParagraphStyle("순서가 중요한 목록");

        ensureCharacterStyle("강조 1");
        ensureCharacterStyle("강조 2");
        ensureCharacterStyle("취소");

        updateProgress(20);

        for(var i = doc.textFrames.length - 1; i >= 0; i--){
            var tf = doc.textFrames[i];
            if(tf.label === "md_frame"){
                try{ tf.remove(); } catch(e) {}
            }
        }

        updateProgress(30);

        var matches = markdownText.match(/\+{3}/g);
        var pageCount = matches ? matches.length + 1 : 1;

        var remainder = pageCount % 4;
        if(remainder !== 0){
            pageCount += (4 - remainder);
        }

        while(doc.pages.length < pageCount){
            try{
                if(masterToUse){
                    doc.pages.add(LocationOptions.AT_END, masterToUse);
                } else {
                    doc.pages.add(LocationOptions.AT_END);
                }
            } catch(e){
                doc.pages.add(LocationOptions.AT_END);
            }
        }

        while(doc.pages.length > pageCount){
            try{ doc.pages[-1].remove(); } catch(e) { break; }
        }

        if(masterToUse){
            for(var k = 0; k < doc.pages.length; k++){
                try{ doc.pages[k].appliedMaster = masterToUse; } catch(e) {}
            }
        }

        updateProgress(40);

        var frames = [];

        for(var p = 0; p < pageCount; p++){

            var page = doc.pages[p];

            var mTop    = page.marginPreferences.top;
            var mBottom = page.marginPreferences.bottom;

            var leftMargin, rightMargin;

            if(page.side == PageSideOptions.LEFT_HAND){
                leftMargin  = page.marginPreferences.right;
                rightMargin = page.marginPreferences.left;
            } else {
                leftMargin  = page.marginPreferences.left;
                rightMargin = page.marginPreferences.right;
            }

            var pageBounds = page.bounds;

            var bounds = [
                pageBounds[0] + mTop,
                pageBounds[1] + leftMargin,
                pageBounds[2] - mBottom,
                pageBounds[3] - rightMargin
            ];

            var frame = page.textFrames.add();
            frame.geometricBounds = bounds;
            frame.label = "md_frame";

            frames.push(frame);
        }

        updateProgress(60);

        for(var j = 0; j < frames.length - 1; j++){
            frames[j].nextTextFrame = frames[j + 1];
        }

        frames[0].parentStory.contents = markdownText;

        updateProgress(70);

        var story = frames[0].parentStory;

        story.paragraphs.everyItem().appliedParagraphStyle = bodyStyle;
        story.characters.everyItem().appliedCharacterStyle = doc.characterStyles.item(0);

        try { story.recompose(); } catch(e) {}

        app.findGrepPreferences = NothingEnum.NOTHING;
        app.changeGrepPreferences = NothingEnum.NOTHING;
        app.findGrepPreferences.findWhat = "(\\r+)?\\+{3}(\\r+)?";
        app.changeGrepPreferences.changeTo = "+++";
        doc.changeGrep();

        app.findGrepPreferences = NothingEnum.NOTHING;
        app.changeGrepPreferences = NothingEnum.NOTHING;
        app.findGrepPreferences.findWhat = "\\+{3}";
        app.changeGrepPreferences.changeTo = "~R";
        doc.changeGrep();

        grepParagraph("^#\\s.+", "제목 1");
        grepParagraph("^##\\s.+", "제목 2");
        grepParagraph("^###\\s.+", "제목 3");
        grepParagraph("^####\\s.+", "제목 4");
        grepParagraph("^#####\\s.+", "제목 5");
        grepParagraph("^######\\s.+", "제목 6");

        grepParagraph("^>\\s.+", "인용문");

        grepParagraph("^[\\-\\*]\\s.+", "순서가 중요하지 않은 목록");
        grepParagraph("^(\\d+)\\.\\s.+", "순서가 중요한 목록");

        var orderedStyle = doc.paragraphStyles.itemByName("순서가 중요한 목록");
        var paragraphs = story.paragraphs;

        var newList = null;
        var lastWasList = false;

        for(var i = 0; i < paragraphs.length; i++){

            var para = paragraphs[i];

            if(para.appliedParagraphStyle == orderedStyle){

                if(!lastWasList){

                    try{
                        newList = doc.numberingLists.add();
                    } catch(e){}

                    try{
                        para.numberingContinue = false;
                        para.numberingRestart = true;
                        if(newList) para.appliedNumberingList = newList;
                    } catch(e){}
                }

                lastWasList = true;

            } else {

                lastWasList = false;
            }
        }

        grepReplace("^(\\d+\\.\\s)", "$1%%INDENT%%");
        grepReplace("^([\\-\\*]\\s)", "$1%%INDENT%%");

        app.findTextPreferences = NothingEnum.NOTHING;
        app.findTextPreferences.findWhat = "%%INDENT%%";

        var foundIndent = doc.findText();

        for(var i = 0; i < foundIndent.length; i++){
            try{
                foundIndent[i].contents = SpecialCharacters.INDENT_HERE_TAB;
            } catch(e){}
        }

        grepReplace("\\*\\*(.+?)\\*\\*", "%%BOLD_START%%$1%%BOLD_END%%");
        grepReplace("(?<!\\*)\\*(?!\\*)(.+?)(?<!\\*)\\*(?!\\*)", "%%ITALIC_START%%$1%%ITALIC_END%%");
        grepReplace("~~([^~]+?)~~", "%%STRIKE_START%%$1%%STRIKE_END%%");
        
        grepCharacter("%%BOLD_START%%(.+?)%%BOLD_END%%", "강조 1");
        grepCharacter("%%ITALIC_START%%(.+?)%%ITALIC_END%%", "강조 2");
        grepCharacter("%%STRIKE_START%%(.+?)%%STRIKE_END%%", "취소");
        
        grepReplace("%%BOLD_START%%", "");
        grepReplace("%%BOLD_END%%", "");
        
        grepReplace("%%ITALIC_START%%", "");
        grepReplace("%%ITALIC_END%%", "");
        
        grepReplace("%%STRIKE_START%%", "");
        grepReplace("%%STRIKE_END%%", "");

        grepReplace("^#+\\s", "");
        grepReplace("^>\\s", "");
        grepReplace("^[\\-\\*]\\s", "");
        grepReplace("^\\d+\\.\\s", "");

        grepReplace("%%ESCAPED_PLUS%%", "+++");
        grepReplace("%%ESCAPED_HASH%%", "#");
        grepReplace("%%ESCAPED_ASTERISK%%", "*");
        grepReplace("%%ESCAPED_SINGLE_TILDE%%", "~");
        grepReplace("%%ESCAPED_BACKSLASH%%", "\\");
        
        grepReplace("%%ESCAPED_GT%%", ">");
        grepReplace("%%ESCAPED_DASH%%", "-");
        

        grepReplace("%%ESCAPED_ORDERED%%", "");
        grepReplace("%%ESCAPED_DOUBLEASTERISK%%", "**");

        updateProgress(90);

        try{ doc.pages[0].appliedMaster = NothingEnum.NOTHING; } catch(e) {}
        try{ doc.pages[doc.pages.length - 1].appliedMaster = NothingEnum.NOTHING; } catch(e) {}

        updateProgress(95);

        for(var p = 0; p < doc.pages.length; p++){

            try{
        
                var page = doc.pages[p];
                var frames = page.textFrames;
        
                if(frames.length === 0) continue;
        
                var contents = "";
        
                for(var f = 0; f < frames.length; f++){
                    contents += frames[f].contents;
                }
        
                contents = contents.replace(/\s+/g, "");
        
                if(contents === ""){
                    page.appliedMaster = NothingEnum.NOTHING;
                }
        
            } catch(e){}
        }

        updateProgress(100);

    }, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT);

    try{
        app.select(NothingEnum.NOTHING);
    } catch(e){}
    
    try{
        app.toolBoxTools.currentTool = ToolBoxTools.SELECTION_TOOL;
    } catch(e){}
    
    try{
        var win = app.activeWindow;
        win.activePage = doc.pages[0];
    } catch(e){}
    
    try{
        win.zoom(ZoomOptions.FIT_PAGE);
    } catch(e){}
    
    try{
        win.centerView();
    } catch(e){}

    function grepParagraph(find, styleName){
        app.findGrepPreferences = NothingEnum.NOTHING;
        app.changeGrepPreferences = NothingEnum.NOTHING;
        app.findGrepPreferences.findWhat = find;
        app.changeGrepPreferences.appliedParagraphStyle = doc.paragraphStyles.itemByName(styleName);
        doc.changeGrep();
    }

    function grepCharacter(find, styleName){
        app.findGrepPreferences = NothingEnum.NOTHING;
        app.changeGrepPreferences = NothingEnum.NOTHING;
        app.findGrepPreferences.findWhat = find;
        app.changeGrepPreferences.appliedCharacterStyle = doc.characterStyles.itemByName(styleName);
        doc.changeGrep();
    }

    function grepReplace(find, replace){
        app.findGrepPreferences = NothingEnum.NOTHING;
        app.changeGrepPreferences = NothingEnum.NOTHING;
        app.findGrepPreferences.findWhat = find;
        app.changeGrepPreferences.changeTo = replace;
        doc.changeGrep();
    }

    

    alert("마크다운 문서를 옮겨왔습니다.");

})();